"""Prepare curated explanation data and local poster assets for the demo.

This script intentionally reuses the existing precomputed recommendations in
demo_data.json. It only adds presentation fields, curated user ids, ratings in
the explanation panel, and local poster paths for the finite story set.
"""

from __future__ import annotations

import csv
import json
import os
import re
import time
from collections import Counter
from pathlib import Path
from typing import Iterable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pandas as pd

from train_movie_sys import DEFAULT_DATA_PATH, load_data, train_test_split


SCRIPT_DIR = Path(__file__).resolve().parent
DATA_PATH = SCRIPT_DIR / "demo_data.json"
POSTER_DIR = SCRIPT_DIR / "static" / "posters"
POSITIVE_THRESHOLD = 4.0
SEED = 42
PERFECT_STORY_USER_COUNT = 5
IMPERFECT_STORY_USER_COUNT = 10
MAX_CARDS_PER_COLUMN = 6


def compact_title(title: str) -> str:
    return re.sub(r"\s*\(\d{4}\)\s*$", "", str(title))


def opinion_for_rating(rating: float) -> str:
    if rating >= 4.5:
        return "loved it"
    if rating >= 4.0:
        return "liked it"
    if rating >= 3.0:
        return "neutral"
    return "not a favorite"


def top_genres(items: Iterable[dict], limit: int = 5) -> list[dict]:
    counts: Counter[str] = Counter()
    for item in items:
        for genre in str(item.get("genres", "")).split("|"):
            if genre and genre != "(no genres listed)":
                counts[genre] += 1
    return [{"genre": genre, "count": count} for genre, count in counts.most_common(limit)]


def explain_profile(history_items: list[dict], predicted_items: list[dict], actual_items: list[dict]) -> dict:
    history_genres = top_genres(history_items)
    preferred = {row["genre"] for row in history_genres}
    evidence = []
    for item in predicted_items:
        overlap = [genre for genre in str(item.get("genres", "")).split("|") if genre in preferred]
        if overlap:
            evidence.append({"title": item["title"], "genres": overlap[:2]})
    hit_count = sum(1 for item in predicted_items if item.get("hit") or item.get("liked"))
    return {
        "profileGenres": history_genres,
        "summary": "The model's recommendation list is compared with the user's strongest historical rating pattern and then validated on held-out likes.",
        "evidence": evidence[:5],
        "hitCount": int(hit_count),
        "actualLikeCount": int(len(actual_items)),
    }


def movie_lookup(movies: pd.DataFrame) -> dict[int, dict]:
    lookup = {}
    for row in movies.itertuples(index=False):
        lookup[int(row.movieId)] = {
            "movieId": int(row.movieId),
            "title": str(row.title),
            "genres": str(row.genres),
        }
    return lookup


def enrich_history(rows: list[dict], movies_by_id: dict[int, dict]) -> list[dict]:
    out = []
    for rank, row in enumerate(rows[:12], start=1):
        movie_id = int(row["movieId"])
        item = dict(movies_by_id.get(movie_id, {"movieId": movie_id, "title": f"Movie {movie_id}", "genres": ""}))
        item["rank"] = rank
        item["rating"] = float(row["rating"])
        item["timestamp"] = int(row["timestamp"])
        item["opinion"] = opinion_for_rating(item["rating"])
        out.append(item)
    return out


def attach_actual_ratings(users: list[dict], test: pd.DataFrame) -> None:
    rating_map = {
        (int(row.userId), int(row.movieId)): float(row.rating)
        for row in test.itertuples(index=False)
    }
    for user in users:
        uid = int(user["userId"])
        for bucket_name in ("actual", "highConfidence"):
            for item in user.get(bucket_name, []):
                rating = rating_map.get((uid, int(item["movieId"])))
                if rating is not None:
                    item["actualRating"] = rating
                    item["liked"] = rating >= POSITIVE_THRESHOLD
        gt_ids = {int(item["movieId"]) for item in user.get("actual", [])}
        for recs in user.get("recommendations", {}).values():
            for item in recs:
                item["hit"] = int(item["movieId"]) in gt_ids


def load_links() -> dict[int, str]:
    path = Path(DEFAULT_DATA_PATH) / "links.csv"
    links = {}
    with path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("tmdbId"):
                links[int(row["movieId"])] = row["tmdbId"]
    return links


def fetch_tmdb_poster_url(tmdb_id: str) -> str | None:
    url = f"https://www.themoviedb.org/movie/{tmdb_id}"
    request = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    html = urlopen(request, timeout=20).read().decode("utf-8", "ignore")
    match = re.search(r'<meta property="og:image" content="([^"]+)"', html)
    if not match:
        return None
    poster_url = match.group(1)
    if "/t/p/" not in poster_url:
        return None
    return poster_url.replace("/w500/", "/w342/")


def download_poster(movie_id: int, tmdb_id: str) -> str | None:
    POSTER_DIR.mkdir(parents=True, exist_ok=True)
    target = POSTER_DIR / f"{movie_id}.jpg"
    if target.exists() and target.stat().st_size > 1000:
        return f"static/posters/{target.name}"
    poster_url = fetch_tmdb_poster_url(tmdb_id)
    if not poster_url:
        return None
    request = Request(poster_url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(request, timeout=30) as response:
        content = response.read()
    if len(content) < 1000:
        return None
    target.write_bytes(content)
    time.sleep(0.08)
    return f"static/posters/{target.name}"


def iter_story_movie_ids(users_by_id: dict[int, dict], story_user_ids: list[int]) -> set[int]:
    movie_ids = set()
    for uid in story_user_ids:
        user = users_by_id[uid]
        for item in user.get("history", [])[:MAX_CARDS_PER_COLUMN]:
            movie_ids.add(int(item["movieId"]))
        for item in user.get("highConfidence", [])[:MAX_CARDS_PER_COLUMN]:
            movie_ids.add(int(item["movieId"]))
        for item in user.get("actual", [])[:MAX_CARDS_PER_COLUMN]:
            movie_ids.add(int(item["movieId"]))
        for item in user.get("recommendations", {}).get("FlowRanking", [])[:MAX_CARDS_PER_COLUMN]:
            movie_ids.add(int(item["movieId"]))
    return movie_ids


def attach_poster_paths(obj, poster_paths: dict[int, str]) -> None:
    if isinstance(obj, dict):
        movie_id = obj.get("movieId")
        if movie_id is not None and int(movie_id) in poster_paths:
            obj["posterPath"] = poster_paths[int(movie_id)]
        for value in obj.values():
            attach_poster_paths(value, poster_paths)
    elif isinstance(obj, list):
        for value in obj:
            attach_poster_paths(value, poster_paths)


def main() -> None:
    with DATA_PATH.open(encoding="utf-8") as f:
        payload = json.load(f)

    ratings, movies = load_data(DEFAULT_DATA_PATH)
    train, test = train_test_split(ratings, test_ratio=0.2, seed=SEED)
    movies_by_id = movie_lookup(movies)

    history_rows = (
        train[train.rating >= POSITIVE_THRESHOLD]
        .sort_values(["userId", "rating", "timestamp"], ascending=[True, False, False])
        .groupby("userId")
        .apply(lambda df: df.head(12).to_dict("records"))
        .to_dict()
    )

    users = payload["users"]
    attach_actual_ratings(users, test)
    for user in users:
        uid = int(user["userId"])
        enriched_history = enrich_history(history_rows.get(uid, []), movies_by_id)
        if enriched_history:
            user["history"] = enriched_history
        predicted = user.get("highConfidence") or user.get("recommendations", {}).get("FlowRanking", [])
        actual = user.get("actual", [])
        user["explanation"] = explain_profile(user.get("history", []), predicted, actual)

    def confidence_stats(user: dict) -> tuple[float, int, int]:
        items = user.get("highConfidence", [])
        hit_count = sum(1 for item in items if item.get("liked"))
        total = len(items)
        return (hit_count / total if total else 0.0, hit_count, total)

    perfect_users = sorted(
        [user for user in users if confidence_stats(user)[0] >= 1.0 and confidence_stats(user)[2] >= 5],
        key=lambda user: (confidence_stats(user)[2], len(user.get("history", [])), int(user["userId"])),
        reverse=True,
    )[:PERFECT_STORY_USER_COUNT]
    imperfect_users = sorted(
        [
            user for user in users
            if 0.70 <= confidence_stats(user)[0] < 1.0 and confidence_stats(user)[2] >= 5
        ],
        key=lambda user: (
            confidence_stats(user)[0],
            confidence_stats(user)[2],
            confidence_stats(user)[1],
            len(user.get("history", [])),
            int(user["userId"]),
        ),
        reverse=True,
    )[:IMPERFECT_STORY_USER_COUNT]
    story_users = perfect_users + imperfect_users
    story_user_ids = [int(user["userId"]) for user in story_users]
    payload["storyUserIds"] = story_user_ids
    payload["storyUserGroups"] = {
        "perfect": [int(user["userId"]) for user in perfect_users],
        "nearPerfect": [int(user["userId"]) for user in imperfect_users],
        "selectionRule": "5 perfect high-confidence cases plus 10 non-perfect cases with 70%-99% precision.",
    }

    users_by_id = {int(user["userId"]): user for user in users}
    required_movie_ids = iter_story_movie_ids(users_by_id, story_user_ids)
    links = load_links()
    poster_paths = {}
    failures = []
    for index, movie_id in enumerate(sorted(required_movie_ids), start=1):
        tmdb_id = links.get(movie_id)
        if not tmdb_id:
            failures.append((movie_id, "missing tmdbId"))
            continue
        try:
            poster_path = download_poster(movie_id, tmdb_id)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            poster_path = None
            failures.append((movie_id, type(exc).__name__))
        if poster_path:
            poster_paths[movie_id] = poster_path
        print(f"poster {index}/{len(required_movie_ids)} movieId={movie_id} {'ok' if poster_path else 'failed'}")

    attach_poster_paths(payload, poster_paths)
    payload["posterAssets"] = {
        "localDir": "static/posters",
        "required": len(required_movie_ids),
        "downloaded": len(poster_paths),
        "failed": [{"movieId": movie_id, "reason": reason} for movie_id, reason in failures],
    }

    with DATA_PATH.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"updated {DATA_PATH}")
    print(f"story users: {story_user_ids}")
    print(f"posters: {len(poster_paths)}/{len(required_movie_ids)}")


if __name__ == "__main__":
    main()
