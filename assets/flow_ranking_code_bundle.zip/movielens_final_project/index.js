import { ControlWavePlugin } from '../plugin-loader.js';

const DATA_URL = '/plugins/movielens-final-project/demo_data.json';
const STORAGE_KEY = 'movielens-recommender-history-v1';
const COLORS = {
    predicted: '#2F80FF',
    actual: '#FF5A6A',
    overlap: '#2F80FF'
};

function hashValue(input, salt = 0) {
    let h = 2166136261 ^ salt;
    const text = String(input);
    for (let i = 0; i < text.length; i += 1) {
        h ^= text.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    return (h >>> 0) / 4294967295;
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function compactTitle(title) {
    return title.replace(/\s*\(\d{4}\)\s*$/, '');
}

export default class MovieLensRecommenderPlugin extends ControlWavePlugin {
    constructor() {
        super({
            id: 'movielens-recommender',
            name: 'MovieLens Recommender',
            version: '0.2.0',
            author: 'Sen Fang',
            description: 'Interactive FlowRanking MovieLens recommendation demo',
            needsViser: false,
            order: 40
        });
        this.data = null;
        this.history = [];
        this.visibleUsers = [];
        this.selectedUserId = null;
        this.selectedModel = 'FlowRanking';
        this.selectedMode = 'confidence';
    }

    async render(container) {
        container.innerHTML = '';
        container.className = 'tab-content active';

        const wrapper = document.createElement('div');
        wrapper.className = 'ml-demo-root';
        wrapper.innerHTML = this.shellTemplate();
        container.appendChild(wrapper);

        this.root = wrapper;
        this.bindEvents();
        this.restoreHistory();

        try {
            const response = await fetch(DATA_URL, { cache: 'no-store' });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            this.data = await response.json();
            this.selectedModel = this.data.models.includes('FlowRanking') ? 'FlowRanking' : this.data.models[0];
            this.pickRandomUsers();
            this.renderModelOptions();
            this.renderMetrics();
            this.renderUsers();
            this.renderStarfield();
            this.setStatus(`Loaded ${this.data.users.length} test users. High-confidence pool: ${this.highConfidenceUsers().length} users.`);
        } catch (error) {
            this.setStatus(`Failed to load demo data: ${error.message}`, true);
        }
    }

    shellTemplate() {
        return `
            <style>
                .ml-demo-root {
                    min-height: 100%;
                    overflow: auto;
                    background:
                        radial-gradient(circle at 12% 8%, rgba(233, 92, 255, 0.18), transparent 28%),
                        radial-gradient(circle at 85% 18%, rgba(47, 128, 255, 0.16), transparent 30%),
                        linear-gradient(135deg, #0b1220 0%, #121a2b 46%, #20172b 100%);
                    color: #eef4ff;
                    padding: 26px;
                    font-family: Avenir Next, Trebuchet MS, Verdana, sans-serif;
                }
                .ml-layout {
                    display: grid;
                    grid-template-columns: minmax(340px, 430px) minmax(420px, 1fr);
                    gap: 18px;
                    max-width: 1440px;
                    margin: 0 auto;
                }
                .ml-card {
                    background: rgba(9, 16, 30, 0.78);
                    border: 1px solid rgba(178, 196, 255, 0.16);
                    border-radius: 18px;
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.32);
                    backdrop-filter: blur(14px);
                }
                .ml-panel { padding: 20px; }
                .ml-title {
                    margin: 0 0 6px;
                    font-family: Georgia, Times New Roman, serif;
                    font-size: 34px;
                    line-height: 1.05;
                    color: #fff7ea;
                }
                .ml-subtitle {
                    margin: 0;
                    color: #aebbd1;
                    line-height: 1.5;
                    font-size: 14px;
                }
                .ml-controls {
                    display: grid;
                    grid-template-columns: 1fr auto;
                    gap: 10px;
                    margin-top: 18px;
                    align-items: center;
                }
                .ml-select, .ml-button {
                    border: 1px solid rgba(178, 196, 255, 0.22);
                    border-radius: 12px;
                    background: rgba(255, 255, 255, 0.08);
                    color: #f5f8ff;
                    padding: 10px 12px;
                    font: inherit;
                }
                .ml-select option { color: #111827; }
                .ml-button {
                    cursor: pointer;
                    font-weight: 750;
                    transition: transform 0.16s ease, background 0.16s ease;
                }
                .ml-button:hover { transform: translateY(-1px); background: rgba(255, 255, 255, 0.14); }
                .ml-button.primary {
                    background: linear-gradient(135deg, #ff5ba8, #e95cff 48%, #6c8cff);
                    border: 0;
                    color: white;
                }
                .ml-button.warn { color: #ffd7d7; }
                .ml-users {
                    display: grid;
                    grid-template-columns: 1fr;
                    gap: 9px;
                    margin-top: 16px;
                }
                .ml-user-card {
                    text-align: left;
                    color: #eef4ff;
                    background: rgba(255, 255, 255, 0.065);
                    border: 1px solid rgba(178, 196, 255, 0.15);
                    border-radius: 14px;
                    padding: 12px;
                    cursor: pointer;
                }
                .ml-user-card.active {
                    border-color: #e95cff;
                    box-shadow: 0 0 0 2px rgba(233, 92, 255, 0.18), inset 0 0 28px rgba(233, 92, 255, 0.08);
                }
                .ml-user-line {
                    display: flex;
                    justify-content: space-between;
                    gap: 8px;
                    font-weight: 800;
                }
                .ml-user-card small {
                    display: block;
                    color: #aebbd1;
                    margin-top: 6px;
                    line-height: 1.35;
                }
                .ml-metrics {
                    display: grid;
                    grid-template-columns: repeat(4, minmax(0, 1fr));
                    gap: 8px;
                    margin-top: 15px;
                }
                .ml-metric {
                    border-radius: 13px;
                    padding: 10px;
                    background: rgba(255, 255, 255, 0.07);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }
                .ml-metric strong { display: block; color: #ffcadf; font-size: 17px; }
                .ml-metric span { color: #aebbd1; font-size: 11px; letter-spacing: 0.04em; text-transform: uppercase; }
                .ml-star-panel {
                    display: grid;
                    grid-template-rows: auto minmax(420px, 1fr) auto;
                    min-height: 690px;
                    overflow: hidden;
                }
                .ml-star-head {
                    display: flex;
                    justify-content: space-between;
                    gap: 14px;
                    padding: 18px 20px 12px;
                    align-items: flex-start;
                }
                .ml-legend {
                    display: flex;
                    gap: 10px;
                    flex-wrap: wrap;
                    color: #bac6d8;
                    font-size: 12px;
                }
                .ml-legend span::before {
                    content: '';
                    display: inline-block;
                    width: 9px;
                    height: 9px;
                    border-radius: 999px;
                    margin-right: 5px;
                    vertical-align: 0;
                }
                .ml-legend .pred::before { background: ${COLORS.predicted}; }
                .ml-legend .gt::before { background: ${COLORS.actual}; }
                .ml-legend .hit::before {
                    background: linear-gradient(90deg, ${COLORS.predicted} 0 50%, ${COLORS.actual} 50% 100%);
                }
                .ml-starfield {
                    position: relative;
                    margin: 0 20px 16px;
                    border-radius: 18px;
                    overflow: hidden;
                    min-height: 430px;
                    background:
                        radial-gradient(circle at 50% 50%, rgba(116, 139, 255, 0.12), transparent 42%),
                        radial-gradient(circle at 20% 70%, rgba(47, 128, 255, 0.10), transparent 28%),
                        #050914;
                    border: 1px solid rgba(178, 196, 255, 0.15);
                }
                .ml-starfield::before {
                    content: '';
                    position: absolute;
                    inset: 0;
                    background-image:
                        radial-gradient(circle, rgba(255,255,255,0.42) 0 1px, transparent 1px),
                        radial-gradient(circle, rgba(255,255,255,0.24) 0 1px, transparent 1px);
                    background-size: 41px 41px, 83px 83px;
                    opacity: 0.34;
                }
                .ml-dot {
                    position: absolute;
                    border-radius: 999px;
                    transform: translate(-50%, -50%);
                    box-shadow: 0 0 16px currentColor;
                    border: 1px solid rgba(255,255,255,0.72);
                    cursor: help;
                }
                .ml-dot.predicted { color: ${COLORS.predicted}; background: ${COLORS.predicted}; }
                .ml-dot.actual { color: ${COLORS.actual}; background: ${COLORS.actual}; }
                .ml-dot.overlap {
                    color: ${COLORS.predicted};
                    background: ${COLORS.predicted};
                    animation: ml-overlap-pulse 1s steps(1, end) infinite;
                }
                @keyframes ml-overlap-pulse {
                    0%, 49% {
                        color: ${COLORS.predicted};
                        background: ${COLORS.predicted};
                        box-shadow: 0 0 16px ${COLORS.predicted}, 0 0 30px rgba(47, 128, 255, 0.50);
                    }
                    50%, 100% {
                        color: ${COLORS.actual};
                        background: ${COLORS.actual};
                        box-shadow: 0 0 16px ${COLORS.actual}, 0 0 30px rgba(255, 90, 106, 0.50);
                    }
                }
                .ml-detail-grid {
                    display: grid;
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                    gap: 12px;
                    padding: 0 20px 20px;
                }
                .ml-list {
                    background: rgba(255, 255, 255, 0.055);
                    border: 1px solid rgba(178, 196, 255, 0.12);
                    border-radius: 14px;
                    padding: 12px;
                    min-height: 150px;
                }
                .ml-list h3 {
                    margin: 0 0 9px;
                    color: #fff7ea;
                    font-size: 15px;
                }
                .ml-list ol {
                    margin: 0;
                    padding-left: 20px;
                    color: #dbe6f8;
                    font-size: 13px;
                    line-height: 1.5;
                }
                .ml-list li.hit { color: #ffb7ff; font-weight: 800; }
                .ml-history {
                    margin-top: 15px;
                    border-top: 1px solid rgba(178, 196, 255, 0.14);
                    padding-top: 14px;
                    color: #d5deef;
                    font-size: 13px;
                    line-height: 1.45;
                }
                .ml-status {
                    min-height: 20px;
                    margin-top: 12px;
                    color: #aebbd1;
                    font-size: 13px;
                }
                .ml-status.error { color: #ffb4b4; }
                @media (max-width: 980px) {
                    .ml-layout { grid-template-columns: 1fr; }
                    .ml-detail-grid { grid-template-columns: 1fr; }
                    .ml-star-head { flex-direction: column; }
                }
            </style>
            <div class="ml-layout">
                <section class="ml-card ml-panel">
                    <h1 class="ml-title">FlowRanking MovieLens Demo</h1>
                    <p class="ml-subtitle">
                        Default mode is high-confidence presentation: FlowRanking only shows movies
                        whose predicted rating is at least 4.5, then checks whether the held-out
                        rating is actually liked. Switch to strict Top-10 for the paper metric view.
                    </p>
                    <div class="ml-metrics" data-role="metrics"></div>
                    <div class="ml-controls">
                        <select class="ml-select" data-role="mode">
                            <option value="confidence">High-Confidence Demo</option>
                            <option value="top10">Strict Top-10 Evaluation</option>
                        </select>
                        <select class="ml-select" data-role="model"></select>
                        <button class="ml-button" data-action="random">Random 5 Users</button>
                        <button class="ml-button primary" data-action="infer">Run Inference</button>
                        <button class="ml-button warn" data-action="clear">Clear Starfield</button>
                    </div>
                    <div class="ml-users" data-role="users"></div>
                    <div class="ml-history" data-role="history">Select a user to inspect training history.</div>
                    <div class="ml-status" data-role="status">Loading demo data...</div>
                </section>
                <section class="ml-card ml-star-panel">
                    <div class="ml-star-head">
                        <div>
                            <h2 style="margin:0 0 6px;color:#fff7ea;">Recommendation Starfield</h2>
                            <p class="ml-subtitle" data-role="star-summary">No inference yet.</p>
                        </div>
                        <div class="ml-legend">
                            <span class="pred">Predicted liked</span>
                            <span class="gt">Actually liked</span>
                            <span class="hit">Correct prediction</span>
                        </div>
                    </div>
                    <div class="ml-starfield" data-role="starfield"></div>
                    <div class="ml-detail-grid">
                        <div class="ml-list">
                            <h3>Latest predicted movies</h3>
                            <ol data-role="predicted-list"></ol>
                        </div>
                        <div class="ml-list">
                            <h3>Latest ground truth liked movies</h3>
                            <ol data-role="actual-list"></ol>
                        </div>
                    </div>
                </section>
            </div>
        `;
    }

    bindEvents() {
        this.root.querySelector('[data-action="random"]').addEventListener('click', () => {
            this.pickRandomUsers();
            this.renderUsers();
        });
        this.root.querySelector('[data-action="infer"]').addEventListener('click', () => this.runInference());
        this.root.querySelector('[data-action="clear"]').addEventListener('click', () => {
            this.history = [];
            this.persistHistory();
            this.renderStarfield();
            this.renderLatestLists(null, null);
            this.setStatus('Starfield cleared. Local history was reset.');
        });
        this.root.querySelector('[data-role="model"]').addEventListener('change', (event) => {
            this.selectedModel = event.target.value;
            this.renderMetrics();
        });
        this.root.querySelector('[data-role="mode"]').addEventListener('change', (event) => {
            this.selectedMode = event.target.value;
            this.pickRandomUsers();
            this.renderMetrics();
            this.renderUsers();
            this.setStatus(this.modeHelpText());
        });
    }

    pickRandomUsers() {
        if (!this.data) return;
        const source = this.selectedMode === 'confidence' ? this.highConfidenceUsers() : this.data.users;
        const pool = [...source];
        for (let i = pool.length - 1; i > 0; i -= 1) {
            const j = Math.floor(Math.random() * (i + 1));
            [pool[i], pool[j]] = [pool[j], pool[i]];
        }
        this.visibleUsers = pool.slice(0, 5);
        this.selectedUserId = this.visibleUsers[0]?.userId ?? null;
    }

    highConfidenceUsers() {
        if (!this.data) return [];
        return this.data.users.filter((user) => (user.highConfidence ?? []).length > 0);
    }

    renderModelOptions() {
        const select = this.root.querySelector('[data-role="model"]');
        select.innerHTML = this.data.models
            .map((model) => `<option value="${escapeHtml(model)}">${escapeHtml(model)}</option>`)
            .join('');
        select.value = this.selectedModel;
    }

    renderMetrics() {
        if (!this.data) return;
        if (this.selectedMode === 'confidence') {
            const task = this.data.highConfidenceTask ?? {};
            const items = [
                ['Precision', task.precision],
                ['Coverage', task.coverage],
                ['Threshold', task.threshold],
                ['Examples', task.examples]
            ];
            this.root.querySelector('[data-role="metrics"]').innerHTML = items.map(([label, value]) => {
                const formatted = label === 'Examples' ? String(value ?? 0) : Number(value ?? 0).toFixed(label === 'Threshold' ? 1 : 4);
                return `<div class="ml-metric"><strong>${formatted}</strong><span>${label}</span></div>`;
            }).join('');
            return;
        }
        const metrics = this.data.metrics[this.selectedModel] ?? {};
        const items = [
            ['P@10', metrics['Precision@10']],
            ['Recall@10', metrics['Recall@10']],
            ['F@10', metrics['F-measure@10']],
            ['NDCG@10', metrics['NDCG@10']]
        ];
        this.root.querySelector('[data-role="metrics"]').innerHTML = items.map(([label, value]) => `
            <div class="ml-metric"><strong>${Number(value).toFixed(4)}</strong><span>${label}</span></div>
        `).join('');
    }

    renderUsers() {
        const usersEl = this.root.querySelector('[data-role="users"]');
        usersEl.innerHTML = this.visibleUsers.map((user) => {
            const active = user.userId === this.selectedUserId ? ' active' : '';
            const source = this.selectedMode === 'confidence' ? user.highConfidence : user.actual;
            const firstActual = (source ?? []).slice(0, 2).map((m) => compactTitle(m.title)).join(' / ');
            const countLabel = this.selectedMode === 'confidence'
                ? `${(user.highConfidence ?? []).length} high-conf`
                : `${user.actual.length} GT likes`;
            return `
                <button class="ml-user-card${active}" data-user-id="${user.userId}">
                    <span class="ml-user-line">
                        <span>User ${user.userId}</span>
                        <span>${countLabel}</span>
                    </span>
                    <small>${this.selectedMode === 'confidence' ? 'High-confidence examples' : 'Held-out examples'}: ${escapeHtml(firstActual || 'none')}</small>
                </button>
            `;
        }).join('');
        usersEl.querySelectorAll('[data-user-id]').forEach((button) => {
            button.addEventListener('click', () => {
                this.selectedUserId = Number(button.dataset.userId);
                this.renderUsers();
            });
        });
        this.renderSelectedHistory();
    }

    renderSelectedHistory() {
        const user = this.getSelectedUser();
        const historyEl = this.root.querySelector('[data-role="history"]');
        if (!user) {
            historyEl.textContent = 'Select a user to inspect training history.';
            return;
        }
        const history = user.history.slice(0, 8).map((m) => compactTitle(m.title)).join(', ');
        const modeNote = this.selectedMode === 'confidence'
            ? `High-confidence candidates: ${(user.highConfidence ?? []).length}.`
            : `Strict GT likes: ${user.actual.length}.`;
        historyEl.innerHTML = `<strong>User ${user.userId} training likes:</strong> ${escapeHtml(history || 'No positive history in train split.')}<br>${escapeHtml(modeNote)}`;
    }

    runInference() {
        const user = this.getSelectedUser();
        if (!user) {
            this.setStatus('Select a user first.', true);
            return;
        }
        const confidenceMode = this.selectedMode === 'confidence';
        const predicted = confidenceMode ? (user.highConfidence ?? []) : (user.recommendations[this.selectedModel] ?? []);
        const actual = confidenceMode ? predicted.filter((movie) => movie.liked) : (user.actual ?? []);
        const actualIds = new Set(actual.map((m) => Number(m.movieId)));
        const predictedIds = new Set(predicted.map((m) => Number(m.movieId)));
        const hitCount = predicted.filter((m) => actualIds.has(Number(m.movieId))).length;
        const event = {
            id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
            time: new Date().toISOString(),
            userId: user.userId,
            model: confidenceMode ? 'FlowRanking High-Confidence' : this.selectedModel,
            mode: this.selectedMode,
            predicted,
            actual,
            hits: hitCount
        };
        this.history.push(event);
        this.persistHistory();
        this.renderStarfield();
        this.renderLatestLists(predicted, actual, predictedIds, actualIds);
        if (confidenceMode) {
            this.setStatus(`User ${user.userId}: ${hitCount}/${predicted.length} high-confidence predictions were actually liked.`);
        } else {
            this.setStatus(`User ${user.userId} with ${this.selectedModel}: ${hitCount}/${actual.length || 10} overlap in the Top-10 comparison.`);
        }
    }

    getSelectedUser() {
        if (!this.data || this.selectedUserId == null) return null;
        return this.data.users.find((user) => user.userId === this.selectedUserId) ?? null;
    }

    renderStarfield() {
        const starfield = this.root.querySelector('[data-role="starfield"]');
        const summary = this.root.querySelector('[data-role="star-summary"]');
        const aggregate = new Map();
        for (const event of this.history) {
            for (const movie of event.predicted ?? []) {
                const key = Number(movie.movieId);
                if (!aggregate.has(key)) aggregate.set(key, { movie, pred: 0, gt: 0 });
                aggregate.get(key).pred += 1;
            }
            for (const movie of event.actual ?? []) {
                const key = Number(movie.movieId);
                if (!aggregate.has(key)) aggregate.set(key, { movie, pred: 0, gt: 0 });
                aggregate.get(key).gt += 1;
            }
        }
        starfield.innerHTML = '';
        for (const [movieId, item] of aggregate.entries()) {
            const kind = item.pred > 0 && item.gt > 0 ? 'overlap' : (item.pred > 0 ? 'predicted' : 'actual');
            const count = item.pred + item.gt;
            const dot = document.createElement('div');
            dot.className = `ml-dot ${kind}`;
            const x = 6 + hashValue(movieId, 17) * 88;
            const y = 8 + hashValue(movieId, 91) * 84;
            const size = Math.min(10 + count * 2.2, 24);
            dot.style.left = `${x}%`;
            dot.style.top = `${y}%`;
            dot.style.width = `${size}px`;
            dot.style.height = `${size}px`;
            dot.style.opacity = String(Math.min(0.58 + count * 0.08, 1));
            dot.title = `${item.movie.title}\nPredicted: ${item.pred}, Ground truth: ${item.gt}`;
            starfield.appendChild(dot);
        }
        const events = this.history.length;
        const predTotal = this.history.reduce((sum, event) => sum + (event.predicted?.length ?? 0), 0);
        const gtTotal = this.history.reduce((sum, event) => sum + (event.actual?.length ?? 0), 0);
        const overlapMovies = [...aggregate.values()].filter((item) => item.pred > 0 && item.gt > 0).length;
        summary.textContent = events
            ? `${events} inference runs, ${predTotal} predicted points, ${gtTotal} GT points, ${overlapMovies} overlapping movie nodes.`
            : this.modeHelpText();
    }

    renderLatestLists(predicted, actual, predictedIds = new Set(), actualIds = new Set()) {
        const predEl = this.root.querySelector('[data-role="predicted-list"]');
        const actualEl = this.root.querySelector('[data-role="actual-list"]');
        predEl.innerHTML = (predicted ?? []).map((movie) => {
            const hit = actualIds.has(Number(movie.movieId)) ? ' class="hit"' : '';
            const score = movie.score ? ` (${Number(movie.score).toFixed(2)} -> ${Number(movie.actualRating ?? 0).toFixed(1)})` : '';
            return `<li${hit}>${escapeHtml(compactTitle(movie.title) + score)}</li>`;
        }).join('');
        actualEl.innerHTML = (actual ?? []).map((movie) => {
            const hit = predictedIds.has(Number(movie.movieId)) ? ' class="hit"' : '';
            const rating = movie.actualRating ? ` (${Number(movie.actualRating).toFixed(1)} stars)` : '';
            return `<li${hit}>${escapeHtml(compactTitle(movie.title) + rating)}</li>`;
        }).join('');
    }

    modeHelpText() {
        if (this.selectedMode === 'confidence') {
            const task = this.data?.highConfidenceTask;
            const precision = task ? `${(task.precision * 100).toFixed(1)}%` : 'about 90%';
            return `High-confidence mode: predicted rating >= 4.5, actual liked = rating >= 4.0. Overall precision: ${precision}.`;
        }
        return 'Strict Top-10 mode: exact overlap between recommended Top-10 and held-out liked movies.';
    }

    restoreHistory() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            this.history = raw ? JSON.parse(raw) : [];
        } catch {
            this.history = [];
        }
    }

    persistHistory() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.history.slice(-80)));
    }

    setStatus(message, isError = false) {
        const status = this.root.querySelector('[data-role="status"]');
        status.textContent = message;
        status.classList.toggle('error', isError);
    }
}
