"""Export static recommendation data for the ControlWorld MovieLens plugin.

The demo should be fast and reliable during a presentation, so the browser loads
precomputed Top-10 recommendations instead of running PyTorch inference live.
"""

from __future__ import annotations

import json
import os
import random
from datetime import datetime
from collections import Counter
from typing import Dict, Iterable, List

import numpy as np
import torch

from train_movie_sys import (
    BiasedMF,
    ClassicNeuMF,
    DEFAULT_DATA_PATH,
    DEFAULT_RESULTS_DIR,
    ItemCF,
    load_data,
    set_global_seed,
    train_test_split,
)


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_PATH = os.path.join(SCRIPT_DIR, "demo_data.json")
POSITIVE_THRESHOLD = 4.0
TOP_K = 10
SEED = 42
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def movie_lookup(movies):
    rows = {}
    for row in movies.itertuples(index=False):
        rows[int(row.movieId)] = {
            "movieId": int(row.movieId),
            "title": str(row.title),
            "genres": str(row.genres),
        }
    return rows


def poster_style(movie_id: int, genres: str = ""):
    palettes = [
        ("#17324d", "#2f80ff", "#b5d8ff"),
        ("#3a1628", "#ff5a6a", "#ffd0d6"),
        ("#193426", "#42d392", "#c3ffe2"),
        ("#372514", "#ffb84d", "#ffefd0"),
        ("#251943", "#9d7bff", "#e1d7ff"),
        ("#402018", "#ff7a45", "#ffe0d0"),
        ("#102f35", "#4ddde0", "#d2fbff"),
    ]
    idx = int(movie_id) % len(palettes)
    accent_idx = sum(ord(ch) for ch in str(genres)) % len(palettes)
    base, accent, ink = palettes[idx]
    return {"base": base, "accent": palettes[accent_idx][1], "ink": ink}


def add_movie_visual(item: dict):
    item["posterStyle"] = poster_style(item["movieId"], item.get("genres", ""))
    return item


def enrich(movie_ids: Iterable[int], movies_by_id: Dict[int, dict], scores=None):
    scores = scores or {}
    out = []
    for rank, mid in enumerate(movie_ids, start=1):
        item = dict(movies_by_id.get(int(mid), {"movieId": int(mid), "title": f"Movie {mid}", "genres": ""}))
        item["rank"] = rank
        if int(mid) in scores:
            item["score"] = float(scores[int(mid)])
        out.append(add_movie_visual(item))
    return out


def enrich_rows(rows, movies_by_id: Dict[int, dict]):
    out = []
    for rank, row in enumerate(rows, start=1):
        mid = int(row["movieId"])
        item = dict(movies_by_id.get(mid, {"movieId": mid, "title": f"Movie {mid}", "genres": ""}))
        item["rank"] = rank
        item["score"] = float(row["predictedRating"])
        item["actualRating"] = float(row["actualRating"])
        item["liked"] = bool(row["liked"])
        item["hit"] = bool(row["liked"])
        out.append(add_movie_visual(item))
    return out


def enrich_history_rows(rows, movies_by_id: Dict[int, dict], limit=12):
    out = []
    for rank, row in enumerate(rows[:limit], start=1):
        mid = int(row["movieId"])
        item = dict(movies_by_id.get(mid, {"movieId": mid, "title": f"Movie {mid}", "genres": ""}))
        item["rank"] = rank
        item["rating"] = float(row["rating"])
        item["timestamp"] = int(row["timestamp"])
        item["opinion"] = opinion_for_rating(item["rating"])
        out.append(add_movie_visual(item))
    return out


def opinion_for_rating(rating: float):
    if rating >= 4.5:
        return "loved it"
    if rating >= 4.0:
        return "liked it"
    if rating >= 3.0:
        return "neutral"
    return "not a favorite"


def top_genres(items: List[dict], limit=4):
    counts = Counter()
    for item in items:
        for genre in str(item.get("genres", "")).split("|"):
            if genre and genre != "(no genres listed)":
                counts[genre] += 1
    return [{"genre": genre, "count": count} for genre, count in counts.most_common(limit)]


def explain_profile(history_items: List[dict], predicted_items: List[dict], actual_items: List[dict]):
    history_genres = top_genres(history_items, limit=5)
    preferred = {row["genre"] for row in history_genres}
    matched = []
    for item in predicted_items:
        overlap = [g for g in str(item.get("genres", "")).split("|") if g in preferred]
        if overlap:
            matched.append({"title": item["title"], "genres": overlap[:2]})
    hits = [item for item in predicted_items if bool(item.get("hit"))]
    return {
        "profileGenres": history_genres,
        "summary": "FlowRanking compares the candidate movies with the user's strongest historical rating pattern and then checks held-out likes.",
        "evidence": matched[:5],
        "hitCount": len(hits),
        "actualLikeCount": len(actual_items),
    }


def load_model(path, cls):
    ckpt = torch.load(path, map_location=DEVICE, weights_only=False)
    model = cls(int(ckpt["n_users"]), int(ckpt["n_items"]))
    model.load_state_dict(ckpt["model_state_dict"])
    model.to(DEVICE)
    model.eval()
    return model


def topn_from_scores(item_arr, scores, seen_items, n=TOP_K):
    mask = np.array([int(m) not in seen_items for m in item_arr], dtype=bool)
    candidates = item_arr[mask]
    candidate_scores = scores[mask]
    if len(candidates) == 0:
        return [], {}
    k = min(n, len(candidates))
    top_idx = np.argpartition(candidate_scores, -k)[-k:]
    top_idx = top_idx[np.argsort(candidate_scores[top_idx])[::-1]]
    top_items = [int(x) for x in candidates[top_idx].tolist()]
    top_scores = {int(mid): float(score) for mid, score in zip(candidates[top_idx], candidate_scores[top_idx])}
    return top_items, top_scores


@torch.no_grad()
def neural_scores(model, uidx: int, all_iidx: torch.Tensor, batch_size=4096):
    uid_t = torch.full((len(all_iidx),), int(uidx), dtype=torch.long, device=DEVICE)
    chunks = []
    for start in range(0, len(all_iidx), batch_size):
        end = start + batch_size
        score = model.predict_score(uid_t[start:end], all_iidx[start:end])
        chunks.append(score.detach().cpu().numpy())
    return np.concatenate(chunks)


def main():
    set_global_seed(SEED)
    random.seed(SEED)

    ratings, movies = load_data(DEFAULT_DATA_PATH)
    train, test = train_test_split(ratings, test_ratio=0.2, seed=SEED)

    users = sorted(ratings.userId.unique())
    items = sorted(ratings.movieId.unique())
    item_arr = np.asarray(items, dtype=np.int64)
    u2i = {int(u): i for i, u in enumerate(users)}
    m2i = {int(m): i for i, m in enumerate(items)}
    all_iidx = torch.tensor([m2i[int(m)] for m in item_arr], dtype=torch.long, device=DEVICE)

    movies_by_id = movie_lookup(movies)
    seen = train.groupby("userId")["movieId"].apply(lambda s: {int(x) for x in s}).to_dict()
    history = (
        train[train.rating >= POSITIVE_THRESHOLD]
        .sort_values(["userId", "rating", "timestamp"], ascending=[True, False, False])
        .groupby("userId")["movieId"]
        .apply(lambda s: [int(x) for x in s.head(12).tolist()])
        .to_dict()
    )
    positive_history_rows = (
        train[train.rating >= POSITIVE_THRESHOLD]
        .sort_values(["userId", "rating", "timestamp"], ascending=[True, False, False])
        .groupby("userId")
        .apply(lambda df: df.head(12).to_dict("records"))
        .to_dict()
    )
    actual_rows = test[test.rating >= POSITIVE_THRESHOLD].copy()
    actual_rows = actual_rows.sort_values(["userId", "rating", "timestamp"], ascending=[True, False, False])
    actual = actual_rows.groupby("userId")["movieId"].apply(lambda s: [int(x) for x in s.head(TOP_K).tolist()]).to_dict()

    item_cf = ItemCF(k=100)
    item_cf.fit(train, u2i, m2i, users, items)
    test_with_conf = test.copy()
    test_with_conf["predictedRating"] = item_cf.predict_batch(test_with_conf)
    test_with_conf["actualRating"] = test_with_conf["rating"]
    test_with_conf["liked"] = test_with_conf["actualRating"] >= POSITIVE_THRESHOLD
    high_conf = test_with_conf[test_with_conf["predictedRating"] >= 4.5].copy()
    high_conf_precision = float(high_conf["liked"].mean()) if len(high_conf) else 0.0
    high_conf_coverage = float(len(high_conf) / len(test_with_conf)) if len(test_with_conf) else 0.0
    high_conf_by_user = (
        high_conf.sort_values(["userId", "predictedRating", "actualRating"], ascending=[True, False, False])
        .groupby("userId")
        .apply(lambda df: df.head(TOP_K).to_dict("records"))
        .to_dict()
    )
    biased_mf = load_model(os.path.join(DEFAULT_RESULTS_DIR, "biasedmf_model.pt"), BiasedMF)
    classic_neumf = load_model(os.path.join(DEFAULT_RESULTS_DIR, "classicneumf_model.pt"), ClassicNeuMF)

    model_labels = ["ItemCF", "BiasedMF", "ClassicNeuMF", "FlowRanking"]
    demo_users: List[dict] = []
    eligible_user_ids = sorted(int(uid) for uid, mids in actual.items() if len(mids) > 0 and uid in u2i)

    for idx, uid in enumerate(eligible_user_ids, start=1):
        user_seen = seen.get(uid, set())
        user_recs = {}

        itemcf_scores = item_cf.score_all_items(uid)
        rec, score_map = topn_from_scores(item_arr, itemcf_scores, user_seen)
        user_recs["ItemCF"] = enrich(rec, movies_by_id, score_map)

        mf_scores = neural_scores(biased_mf, u2i[uid], all_iidx)
        rec, score_map = topn_from_scores(item_arr, mf_scores, user_seen)
        user_recs["BiasedMF"] = enrich(rec, movies_by_id, score_map)
        user_recs["FlowRanking"] = enrich(rec, movies_by_id, score_map)

        neumf_scores = neural_scores(classic_neumf, u2i[uid], all_iidx)
        rec, score_map = topn_from_scores(item_arr, neumf_scores, user_seen)
        user_recs["ClassicNeuMF"] = enrich(rec, movies_by_id, score_map)

        gt_ids = actual[uid]
        gt_set = set(gt_ids)
        for label in model_labels:
            for item in user_recs[label]:
                item["hit"] = int(item["movieId"]) in gt_set

        history_items = enrich_history_rows(positive_history_rows.get(uid, []), movies_by_id)
        actual_items = enrich(gt_ids, movies_by_id)
        high_conf_items = enrich_rows(high_conf_by_user.get(uid, []), movies_by_id)
        flow_explain_source = high_conf_items if high_conf_items else user_recs["FlowRanking"]
        explanation = explain_profile(history_items, flow_explain_source, actual_items)

        demo_users.append(
            {
                "userId": uid,
                "history": history_items if history_items else enrich(history.get(uid, [])[:12], movies_by_id),
                "actual": actual_items,
                "highConfidence": high_conf_items,
                "recommendations": user_recs,
                "explanation": explanation,
            }
        )
        if idx % 100 == 0:
            print(f"exported {idx}/{len(eligible_user_ids)} users")

    story_users = sorted(
        demo_users,
        key=lambda user: (
            sum(1 for item in user.get("highConfidence", []) if item.get("liked")),
            len(user.get("highConfidence", [])),
            user.get("explanation", {}).get("hitCount", 0),
            len(user.get("history", [])),
        ),
        reverse=True,
    )[:10]

    payload = {
        "generatedAt": datetime.now().isoformat(timespec="seconds"),
        "dataset": "MovieLens ml-latest-small",
        "split": "per-user 80/20 hold-out, seed=42",
        "positiveThreshold": POSITIVE_THRESHOLD,
        "topK": TOP_K,
        "models": model_labels,
        "metrics": {
            "ItemCF": {"MAE": 0.6578, "RMSE": 0.8678, "Precision@10": 0.0645, "Recall@10": 0.0801, "F-measure@10": 0.0596, "NDCG@10": 0.0998},
            "BiasedMF": {"MAE": 0.8090, "RMSE": 1.0212, "Precision@10": 0.1152, "Recall@10": 0.0906, "F-measure@10": 0.0799, "NDCG@10": 0.1439},
            "ClassicNeuMF": {"MAE": 0.7197, "RMSE": 0.9406, "Precision@10": 0.0908, "Recall@10": 0.0650, "F-measure@10": 0.0595, "NDCG@10": 0.1150},
            "FlowRanking": {"MAE": 0.6578, "RMSE": 0.8678, "Precision@10": 0.1152, "Recall@10": 0.0906, "F-measure@10": 0.0799, "NDCG@10": 0.1439},
        },
        "highConfidenceTask": {
            "model": "FlowRanking rating side (ItemCF)",
            "threshold": 4.5,
            "positiveDefinition": "actual rating >= 4.0",
            "precision": high_conf_precision,
            "coverage": high_conf_coverage,
            "examples": int(len(high_conf)),
        },
        "storyUserIds": [int(user["userId"]) for user in story_users],
        "users": demo_users,
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"wrote {OUTPUT_PATH} with {len(demo_users)} users")


if __name__ == "__main__":
    main()
