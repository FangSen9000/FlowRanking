# MovieLens ACM Paper Draft

This folder contains an extracted ACM conference template plus a starter paper draft for the CS550 final project.

Files to edit first:

- `movielens_recommender_paper.tex`
- `movielens_refs.bib`

Immediate TODOs:

1. Replace `Student Name` and email in the author block.
2. Copy the final 4-model metrics into Table 1.
3. Add one screenshot of the training/result interface or demo if required.
4. If the instructor wants a shorter report, compress the Discussion section.

Suggested build commands:

```bash
pdflatex movielens_recommender_paper.tex
bibtex movielens_recommender_paper
pdflatex movielens_recommender_paper.tex
pdflatex movielens_recommender_paper.tex
```

Recommended final submission bundle for the course:

- project code
- paper/report PDF
- presentation slides
- optional demo screenshot or demo link if you prepare one
